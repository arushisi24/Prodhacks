import { ReactNode } from "react";

interface ChatBubbleProps {
  message: string | ReactNode;
  sender: "bot" | "user";
  timestamp?: string;
  expandableContent?: ReactNode;
}

export function ChatBubble({ message, sender, expandableContent }: ChatBubbleProps) {
  const isBot = sender === "bot";

  return (
    <div className={`flex ${isBot ? 'justify-start' : 'justify-end'} mb-4`}>
      <div className={`max-w-[80%] ${isBot ? '' : 'max-w-[70%]'}`}>
        <div
          className={`rounded-xl p-4 ${
            isBot
              ? 'bg-card border border-border'
              : 'bg-primary text-primary-foreground'
          }`}
        >
          <div className="text-base leading-relaxed">{message}</div>
          {expandableContent && (
            <div className="mt-3 pt-3 border-t border-border/50">
              {expandableContent}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
