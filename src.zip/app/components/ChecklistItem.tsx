import { ChevronDown, ChevronUp, Upload, CheckCircle2, AlertCircle } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface ChecklistItemProps {
  title: string;
  required: boolean;
  status: "missing" | "uploaded" | "reviewed";
  whyNeeded?: string;
  whereToFind?: string;
  onUpload?: () => void;
  onReview?: () => void;
}

export function ChecklistItem({
  title,
  required,
  status,
  whyNeeded,
  whereToFind,
  onUpload,
  onReview,
}: ChecklistItemProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3 flex-1">
          <div className="mt-1">
            {status === "reviewed" ? (
              <CheckCircle2 className="w-5 h-5 text-primary" />
            ) : status === "uploaded" ? (
              <AlertCircle className="w-5 h-5 text-warning" />
            ) : (
              <div className="w-5 h-5 rounded-full border-2 border-muted" />
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-medium text-base">{title}</h4>
              <Badge variant={required ? "default" : "secondary"} className="text-xs">
                {required ? "Required" : "Optional"}
              </Badge>
            </div>
            {expanded && (
              <div className="mt-3 space-y-3 text-sm text-muted-foreground">
                {whyNeeded && (
                  <div>
                    <p className="font-medium text-foreground mb-1">Why we need this</p>
                    <p>{whyNeeded}</p>
                  </div>
                )}
                {whereToFind && (
                  <div>
                    <p className="font-medium text-foreground mb-1">Where to find it</p>
                    <p>{whereToFind}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {status === "uploaded" && onReview && (
            <Button size="sm" onClick={onReview}>
              Review
            </Button>
          )}
          {status === "missing" && onUpload && (
            <Button size="sm" onClick={onUpload}>
              <Upload className="w-4 h-4 mr-2" />
              Upload
            </Button>
          )}
          <button
            onClick={() => setExpanded(!expanded)}
            className="p-1 hover:bg-muted rounded"
          >
            {expanded ? (
              <ChevronUp className="w-5 h-5" />
            ) : (
              <ChevronDown className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
