interface ConfidenceMeterProps {
  level: "high" | "medium" | "low";
}

export function ConfidenceMeter({ level }: ConfidenceMeterProps) {
  const percentage = level === "high" ? 90 : level === "medium" ? 60 : 30;
  const color = level === "high" ? "bg-primary" : level === "medium" ? "bg-warning" : "bg-destructive";

  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center text-xs">
        <span className="text-muted-foreground">Confidence</span>
        <span className="font-medium capitalize">{level}</span>
      </div>
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div
          className={`h-full ${color} transition-all duration-500`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
