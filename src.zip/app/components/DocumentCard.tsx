import { FileText, AlertCircle, CheckCircle2 } from "lucide-react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

interface DocumentCardProps {
  filename: string;
  type: string;
  status: "extracted" | "needs-review" | "verified";
  confidence?: "high" | "medium" | "low";
  onReview?: () => void;
}

export function DocumentCard({ filename, type, status, confidence, onReview }: DocumentCardProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-sm transition-shadow">
      <div className="flex items-start gap-3">
        <div className="p-2 bg-secondary rounded">
          <FileText className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm truncate">{filename}</p>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline" className="text-xs">
              {type}
            </Badge>
            {confidence && (
              <Badge
                variant={
                  confidence === "high"
                    ? "default"
                    : confidence === "medium"
                    ? "secondary"
                    : "destructive"
                }
                className="text-xs"
              >
                {confidence === "high" ? "High" : confidence === "medium" ? "Med" : "Low"} confidence
              </Badge>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {status === "verified" ? (
            <CheckCircle2 className="w-5 h-5 text-primary" />
          ) : status === "needs-review" ? (
            <AlertCircle className="w-5 h-5 text-warning" />
          ) : null}
          {onReview && status !== "verified" && (
            <Button size="sm" variant="outline" onClick={onReview}>
              Review
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
