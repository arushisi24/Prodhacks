import { Check } from "lucide-react";

interface Step {
  number: number;
  title: string;
  status: "complete" | "current" | "upcoming";
}

interface ProgressStepperProps {
  steps: Step[];
  orientation?: "vertical" | "horizontal";
}

export function ProgressStepper({ steps, orientation = "vertical" }: ProgressStepperProps) {
  return (
    <div className={`flex ${orientation === "vertical" ? "flex-col" : "flex-row items-center"} gap-2`}>
      {steps.map((step, index) => (
        <div key={step.number} className={`flex ${orientation === "vertical" ? "flex-row" : "flex-col"} items-center gap-3`}>
          <div className="flex items-center gap-3">
            <div
              className={`flex items-center justify-center w-8 h-8 rounded-full flex-shrink-0 ${
                step.status === "complete"
                  ? "bg-primary text-primary-foreground"
                  : step.status === "current"
                  ? "bg-primary text-primary-foreground ring-4 ring-primary/20"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {step.status === "complete" ? (
                <Check className="w-4 h-4" />
              ) : (
                <span className="text-sm font-medium">{step.number}</span>
              )}
            </div>
            {orientation === "vertical" && (
              <span
                className={`text-sm ${
                  step.status === "current" ? "font-semibold text-foreground" : "text-muted-foreground"
                }`}
              >
                {step.title}
              </span>
            )}
          </div>
          {orientation === "vertical" && index < steps.length - 1 && (
            <div className="w-0.5 h-8 bg-border ml-4" />
          )}
          {orientation === "horizontal" && index < steps.length - 1 && (
            <div className="h-0.5 w-12 bg-border" />
          )}
        </div>
      ))}
    </div>
  );
}
