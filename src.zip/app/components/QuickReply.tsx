interface QuickReplyProps {
  text: string;
  onClick: () => void;
}

export function QuickReply({ text, onClick }: QuickReplyProps) {
  return (
    <button
      onClick={onClick}
      className="inline-flex items-center px-4 py-2 rounded-lg border-2 border-primary/20 bg-card hover:bg-secondary hover:border-primary/40 transition-all text-base"
    >
      {text}
    </button>
  );
}
