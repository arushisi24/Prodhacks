import { Upload } from "lucide-react";
import { useState } from "react";

interface UploadDropzoneProps {
  onFileSelect: (files: FileList) => void;
  acceptedTypes?: string[];
}

export function UploadDropzone({
  onFileSelect,
  acceptedTypes = [".pdf", ".jpg", ".jpeg", ".png"],
}: UploadDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDragIn = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragOut = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFileSelect(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileSelect(e.target.files);
    }
  };

  return (
    <div
      onDragEnter={handleDragIn}
      onDragLeave={handleDragOut}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${
        isDragging
          ? "border-primary bg-secondary"
          : "border-border bg-card hover:border-primary/50 hover:bg-secondary/50"
      }`}
    >
      <input
        type="file"
        id="file-upload"
        className="hidden"
        multiple
        accept={acceptedTypes.join(",")}
        onChange={handleFileInput}
      />
      <label htmlFor="file-upload" className="cursor-pointer">
        <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
        <p className="text-base font-medium mb-2">
          Drag & drop files here, or click to browse
        </p>
        <p className="text-sm text-muted-foreground">
          Supports PDF, JPG, PNG (max 10MB each)
        </p>
      </label>
    </div>
  );
}
