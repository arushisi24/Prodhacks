import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { X, MessageCircle, FileText, LayoutDashboard, Chrome } from "lucide-react";

interface WelcomeOverlayProps {
  onClose: () => void;
}

export function WelcomeOverlay({ onClose }: WelcomeOverlayProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 300);
  };

  return (
    <div
      className={`fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 transition-opacity duration-300 ${
        isVisible ? "opacity-100" : "opacity-0"
      }`}
      onClick={handleClose}
    >
      <Card
        className={`max-w-2xl w-full max-h-[90vh] overflow-y-auto transition-transform duration-300 ${
          isVisible ? "scale-100" : "scale-95"
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <CardContent className="p-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-2xl font-semibold mb-2">Welcome to FAFSA Buddy</h2>
              <p className="text-muted-foreground">
                A complete UI prototype for helping first-gen students complete the FAFSA
              </p>
            </div>
            <button
              onClick={handleClose}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-6">
            <div className="bg-secondary/30 border border-border rounded-lg p-4">
              <p className="text-sm">
                <strong>Navigation:</strong> Use the tabs at the bottom (mobile) or navigate
                between pages to explore the complete flow.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold">App Flow:</h3>
              <div className="space-y-3">
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <MessageCircle className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">1. Onboarding Chat</h4>
                    <p className="text-sm text-muted-foreground">
                      Conversational intake with stepper, quick replies, and expandable help
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">2. Document Checklist & Upload</h4>
                    <p className="text-sm text-muted-foreground">
                      Personalized checklist with drag-and-drop upload and document review
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <LayoutDashboard className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">3. Dashboard & Progress</h4>
                    <p className="text-sm text-muted-foreground">
                      Mission control showing progress, next actions, and document status
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Chrome className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">4. Chrome Extension UI</h4>
                    <p className="text-sm text-muted-foreground">
                      Popup, side panel, and highlight tooltip for helping on studentaid.gov
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
              <h4 className="font-medium mb-2">Design System</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Inter font family, 8pt spacing system</li>
                <li>• Blue/teal accent (#0F7A8A) with neutral backgrounds</li>
                <li>• High contrast, big readable type</li>
                <li>• Complete reusable component library</li>
              </ul>
            </div>

            <div className="flex gap-3">
              <Button onClick={handleClose} className="flex-1">
                Start Exploring
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  window.open("/style-guide", "_blank");
                }}
                className="flex-1"
              >
                View Components
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
