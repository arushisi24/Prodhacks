import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { ProgressStepper } from "../components/ProgressStepper";
import { MobileNav } from "../components/MobileNav";
import { CheckCircle2, FileText, Upload, ExternalLink, ArrowRight } from "lucide-react";

export function Dashboard() {
  const navigate = useNavigate();

  const steps = [
    { number: 1, title: "Intake", status: "complete" as const },
    { number: 2, title: "Docs uploaded", status: "complete" as const },
    { number: 3, title: "Review complete", status: "current" as const },
    { number: 4, title: "Start FAFSA", status: "upcoming" as const },
  ];

  return (
    <div className="min-h-screen bg-background pb-16 lg:pb-0">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-6xl mx-auto px-4 md:px-6 py-6 md:py-8">
          <h1 className="text-3xl md:text-4xl font-semibold mb-2">Welcome back!</h1>
          <p className="text-base text-muted-foreground">
            You're making great progress. Here's where you stand.
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 md:px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Progress Card */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
              <CardDescription>You've completed 3 out of 4 steps</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center py-6">
                <ProgressStepper steps={steps} orientation="horizontal" />
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle>Documents</CardTitle>
              <CardDescription>Status overview</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                  <span className="text-sm">Verified</span>
                </div>
                <span className="font-semibold">3</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Upload className="w-5 h-5 text-warning" />
                  <span className="text-sm">Needs review</span>
                </div>
                <span className="font-semibold">1</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm">Missing</span>
                </div>
                <span className="font-semibold">2</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Next Best Action */}
        <Card className="border-primary/50 bg-secondary/30 mb-8">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle>Next Best Action</CardTitle>
                <CardDescription className="mt-2">
                  We recommend completing this before starting your FAFSA
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold mb-1">Upload parent tax return</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Since you're a dependent student, we need your parent's or guardian's tax
                  information. This is required for your FAFSA.
                </p>
                <Button variant="outline" size="sm">
                  How to find it
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
            <Button className="w-full md:w-auto" onClick={() => navigate("/checklist")}>
              Go to checklist
            </Button>
          </CardContent>
        </Card>

        {/* Main CTA */}
        <Card className="border-2 border-primary">
          <CardContent className="p-8">
            <div className="max-w-2xl mx-auto text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
                <CheckCircle2 className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-2xl font-semibold mb-3">Ready to start your FAFSA?</h2>
              <p className="text-muted-foreground mb-6">
                We've gathered your information and you're all set. Let's walk through how to use
                the FAFSA Buddy extension to complete your application with confidence.
              </p>
              <Button size="lg" onClick={() => navigate("/start-fafsa")}>
                Start FAFSA Application
                <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
              <p className="text-xs text-muted-foreground mt-4">
                We never submit FAFSA for you. We help you understand and copy the right values.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Additional Resources */}
        <div className="mt-8 grid md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Need to update your info?</CardTitle>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full" onClick={() => navigate("/checklist")}>
                Edit documents
              </Button>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Have questions?</CardTitle>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full" onClick={() => navigate("/")}>
                Chat with FAFSA Buddy
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <MobileNav />
    </div>
  );
}