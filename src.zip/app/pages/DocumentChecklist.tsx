import { useState } from "react";
import { useNavigate } from "react-router";
import { ChecklistItem } from "../components/ChecklistItem";
import { DocumentCard } from "../components/DocumentCard";
import { UploadDropzone } from "../components/UploadDropzone";
import { MobileNav } from "../components/MobileNav";
import { Button } from "../components/ui/button";
import { Progress } from "../components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../components/ui/dialog";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Eye, EyeOff, CheckCircle2, AlertCircle, ArrowLeft } from "lucide-react";

export function DocumentChecklist() {
  const navigate = useNavigate();
  const [uploadedDocs, setUploadedDocs] = useState<any[]>([]);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<any>(null);
  const [showSSN, setShowSSN] = useState(false);

  const handleFileUpload = (files: FileList) => {
    const newDocs = Array.from(files).map((file, index) => ({
      id: uploadedDocs.length + index + 1,
      filename: file.name,
      type: file.name.includes("W-2") ? "W-2" : file.name.includes("1040") ? "Form 1040" : "Bank Statement",
      status: "needs-review" as const,
      confidence: "medium" as const,
    }));
    setUploadedDocs([...uploadedDocs, ...newDocs]);
  };

  const handleReview = (doc: any) => {
    setSelectedDoc(doc);
    setReviewModalOpen(true);
  };

  const handleConfirmInfo = () => {
    if (selectedDoc) {
      setUploadedDocs(
        uploadedDocs.map((doc) =>
          doc.id === selectedDoc.id ? { ...doc, status: "verified", confidence: "high" } : doc
        )
      );
    }
    setReviewModalOpen(false);
  };

  const completionPercentage = 45;

  return (
    <div className="min-h-screen bg-background pb-16 lg:pb-0">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-6xl mx-auto px-4 md:px-6 py-4 md:py-6">
          <Button
            variant="ghost"
            size="sm"
            className="mb-4"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h1 className="text-2xl md:text-3xl font-semibold mb-2">
                Your FAFSA Document Checklist
              </h1>
              <p className="text-base text-muted-foreground">
                Upload what you have. We'll guide you to find the rest.
              </p>
            </div>
            <div className="hidden md:block">
              <div className="text-right">
                <div className="text-sm text-muted-foreground mb-1">Completion</div>
                <div className="flex items-center gap-2">
                  <Progress value={completionPercentage} className="w-32" />
                  <span className="text-lg font-semibold">{completionPercentage}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 md:px-6 py-6 md:py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column: Checklist */}
          <div>
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4">Identity Documents</h2>
              <div className="space-y-3">
                <ChecklistItem
                  title="Social Security Number"
                  required={true}
                  status="missing"
                  whyNeeded="Required by federal law to process your FAFSA application and determine eligibility."
                  whereToFind="Check your Social Security card, tax documents, or paycheck stub."
                />
                <ChecklistItem
                  title="Driver's License or State ID"
                  required={true}
                  status="missing"
                  whyNeeded="Verifies your identity and residency status."
                  whereToFind="Your physical ID card or digital copy from your state's DMV."
                />
              </div>
            </div>

            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4">Taxes & Income</h2>
              <div className="space-y-3">
                <ChecklistItem
                  title="Federal Tax Return (Form 1040)"
                  required={true}
                  status={uploadedDocs.some((d) => d.type === "Form 1040") ? "uploaded" : "missing"}
                  whyNeeded="Shows your household's income to calculate financial need."
                  whereToFind="Download from IRS.gov, check your email from tax software, or contact your tax preparer."
                  onUpload={() => {}}
                  onReview={
                    uploadedDocs.some((d) => d.type === "Form 1040")
                      ? () => handleReview(uploadedDocs.find((d) => d.type === "Form 1040"))
                      : undefined
                  }
                />
                <ChecklistItem
                  title="W-2 Forms"
                  required={true}
                  status={uploadedDocs.some((d) => d.type === "W-2") ? "uploaded" : "missing"}
                  whyNeeded="Reports wages earned from employment."
                  whereToFind="Mailed by your employer in January, or available through your employer's payroll portal."
                  onUpload={() => {}}
                  onReview={
                    uploadedDocs.some((d) => d.type === "W-2")
                      ? () => handleReview(uploadedDocs.find((d) => d.type === "W-2"))
                      : undefined
                  }
                />
              </div>
            </div>

            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4">Banking & Assets</h2>
              <div className="space-y-3">
                <ChecklistItem
                  title="Bank Account Statements"
                  required={false}
                  status={uploadedDocs.some((d) => d.type === "Bank Statement") ? "uploaded" : "missing"}
                  whyNeeded="Shows current cash and savings to assess financial situation."
                  whereToFind="Log into your bank's website or mobile app to download recent statements."
                  onUpload={() => {}}
                  onReview={
                    uploadedDocs.some((d) => d.type === "Bank Statement")
                      ? () => handleReview(uploadedDocs.find((d) => d.type === "Bank Statement"))
                      : undefined
                  }
                />
              </div>
            </div>
          </div>

          {/* Right Column: Upload & Documents */}
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold mb-4">Upload Documents</h2>
              <UploadDropzone onFileSelect={handleFileUpload} />
            </div>

            {uploadedDocs.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-4">Uploaded Documents</h2>
                <div className="space-y-3">
                  {uploadedDocs.map((doc) => (
                    <DocumentCard
                      key={doc.id}
                      filename={doc.filename}
                      type={doc.type}
                      status={doc.status}
                      confidence={doc.confidence}
                      onReview={() => handleReview(doc)}
                    />
                  ))}
                </div>
              </div>
            )}

            <div className="bg-secondary/30 border border-primary/20 rounded-lg p-6">
              <h3 className="font-semibold mb-2">Ready for the next step?</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Once you've uploaded and reviewed your documents, we'll help you start your FAFSA.
              </p>
              <Button onClick={() => navigate("/dashboard")} className="w-full">
                Continue to Dashboard
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Review Modal */}
      <Dialog open={reviewModalOpen} onOpenChange={setReviewModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Review Extracted Information</DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <div className="bg-secondary/30 border border-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="w-5 h-5 text-primary" />
                <span className="font-medium">We found the following information</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Please verify that these details are correct.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" defaultValue="John A. Smith" className="mt-1" />
                <Badge variant="default" className="mt-2 text-xs">
                  High confidence
                </Badge>
              </div>

              <div>
                <Label htmlFor="ssn">Social Security Number</Label>
                <div className="relative mt-1">
                  <Input
                    id="ssn"
                    type={showSSN ? "text" : "password"}
                    defaultValue="123456789"
                    className="pr-10"
                  />
                  <button
                    onClick={() => setShowSSN(!showSSN)}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                  >
                    {showSSN ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <Badge variant="secondary" className="mt-2 text-xs">
                  Medium confidence
                </Badge>
              </div>

              <div>
                <Label htmlFor="income">Adjusted Gross Income</Label>
                <Input id="income" defaultValue="$45,230" className="mt-1" />
                <Badge variant="default" className="mt-2 text-xs">
                  High confidence
                </Badge>
              </div>
            </div>

            <div className="flex items-start gap-2 p-3 bg-muted rounded-lg">
              <AlertCircle className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                You can edit any field above. If something doesn't look right, update it before confirming.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setReviewModalOpen(false)}>
              Back to checklist
            </Button>
            <Button onClick={handleConfirmInfo}>Confirm info</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <MobileNav />
    </div>
  );
}