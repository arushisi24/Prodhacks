import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Switch } from "../components/ui/switch";
import { ConfidenceMeter } from "../components/ConfidenceMeter";
import { MobileNav } from "../components/MobileNav";
import {
  ArrowLeft,
  CheckCircle2,
  Copy,
  ChevronDown,
  ChevronUp,
  FileText,
  RefreshCw,
  PanelRightClose,
  PanelRightOpen,
  Search,
  AlertCircle,
  ExternalLink,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "../components/ui/collapsible";

export function ExtensionDemo() {
  const navigate = useNavigate();
  const [isPanelOpen, setIsPanelOpen] = useState(true);
  const [isPopoverVisible, setIsPopoverVisible] = useState(false);
  const [extensionEnabled, setExtensionEnabled] = useState(true);
  const [copiedValue, setCopiedValue] = useState(false);
  const [sourcesExpanded, setSourcesExpanded] = useState(false);

  const handleCopy = () => {
    setCopiedValue(true);
    setTimeout(() => setCopiedValue(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 md:py-6">
          <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/start-fafsa")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1 className="text-2xl md:text-3xl font-semibold mb-2">Chrome Extension Demo</h1>
          <p className="text-sm text-muted-foreground">
            See how FAFSA Buddy helps you fill out the form on studentaid.gov
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        <Tabs defaultValue="popup" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="popup">Extension Popup</TabsTrigger>
            <TabsTrigger value="panel">Side Panel</TabsTrigger>
            <TabsTrigger value="tooltip">Highlight Tooltip</TabsTrigger>
          </TabsList>

          {/* Extension Popup State */}
          <TabsContent value="popup">
            <Card className="max-w-md mx-auto">
              <CardHeader className="bg-primary text-primary-foreground">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">FAFSA Buddy</CardTitle>
                  <Badge variant="secondary" className="bg-primary-foreground/20 text-primary-foreground">
                    Connected
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium">Active on studentaid.gov</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Detect FAFSA questions</p>
                      <p className="text-xs text-muted-foreground">Show help for form fields</p>
                    </div>
                    <Switch checked={extensionEnabled} onCheckedChange={setExtensionEnabled} />
                  </div>
                </div>

                <div className="pt-3 border-t border-border space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <PanelRightOpen className="w-4 h-4 mr-2" />
                    Open assistant panel
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Re-sync documents
                  </Button>
                </div>

                <div className="pt-3 border-t border-border">
                  <p className="text-xs text-muted-foreground text-center">
                    3 documents synced • Last updated 2 min ago
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Side Panel State */}
          <TabsContent value="panel">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Mock FAFSA Form */}
              <div className="lg:col-span-2 bg-card border border-border rounded-lg p-6">
                <div className="mb-6">
                  <div className="bg-blue-900 text-white p-4 rounded-t-lg -m-6 mb-6">
                    <h2 className="text-xl font-semibold">Federal Student Aid</h2>
                    <p className="text-sm opacity-90">FAFSA® Application</p>
                  </div>
                </div>

                <h3 className="text-lg font-semibold mb-4">Student Demographics</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      What is your Social Security Number?
                    </label>
                    <Input
                      placeholder="XXX-XX-XXXX"
                      className="max-w-xs"
                      onFocus={() => setIsPopoverVisible(true)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      What is your date of birth?
                    </label>
                    <Input type="date" className="max-w-xs" />
                  </div>
                </div>
              </div>

              {/* Side Panel */}
              <div
                className={`bg-card border-l-2 border-primary rounded-lg shadow-lg transition-all ${
                  isPanelOpen ? "w-full" : "w-12"
                }`}
              >
                {isPanelOpen ? (
                  <div className="h-full flex flex-col">
                    <div className="p-4 border-b border-border flex items-center justify-between">
                      <h3 className="font-semibold">FAFSA Buddy</h3>
                      <button onClick={() => setIsPanelOpen(false)}>
                        <PanelRightClose className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="p-4 border-b border-border">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input placeholder="Ask about this page…" className="pl-9" />
                      </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                      <Card className="border-primary/50 bg-secondary/30">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-2 mb-3">
                            <AlertCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="font-medium text-sm mb-1">Current field help</p>
                              <p className="text-sm text-muted-foreground">
                                Social Security Number
                              </p>
                            </div>
                          </div>

                          <div className="bg-card rounded-lg p-3 mb-3">
                            <p className="text-sm mb-2">
                              <strong>What this means:</strong> Your SSN is used to identify you
                              in federal records.
                            </p>
                            <p className="text-sm">
                              <strong>What to enter:</strong> Your 9-digit Social Security Number
                            </p>
                          </div>

                          <div className="space-y-2">
                            <p className="text-xs text-muted-foreground">Suggested value:</p>
                            <div className="flex gap-2">
                              <Input value="XXX-XX-6789" className="flex-1" readOnly />
                              <Button size="sm" onClick={handleCopy}>
                                {copiedValue ? (
                                  <CheckCircle2 className="w-4 h-4" />
                                ) : (
                                  <Copy className="w-4 h-4" />
                                )}
                              </Button>
                            </div>
                            <ConfidenceMeter level="high" />
                          </div>

                          <button
                            onClick={() => setSourcesExpanded(!sourcesExpanded)}
                            className="flex items-center gap-1 text-sm text-primary hover:underline mt-3"
                          >
                            <FileText className="w-4 h-4" />
                            Show source
                            {sourcesExpanded ? (
                              <ChevronUp className="w-4 h-4" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </button>

                          {sourcesExpanded && (
                            <div className="mt-3 p-3 bg-muted rounded-lg">
                              <p className="text-xs font-medium mb-2">Source documents:</p>
                              <div className="space-y-2">
                                <div className="flex items-center gap-2 text-xs">
                                  <FileText className="w-3 h-3" />
                                  <span>Form 1040 (2025) - Page 1</span>
                                </div>
                                <div className="flex items-center gap-2 text-xs">
                                  <FileText className="w-3 h-3" />
                                  <span>W-2 Form - Box a</span>
                                </div>
                              </div>
                            </div>
                          )}

                          <Button variant="link" size="sm" className="mt-2 p-0 h-auto text-xs">
                            Not right? Give feedback
                          </Button>
                        </CardContent>
                      </Card>

                      <div className="text-xs text-muted-foreground text-center">
                        3 documents synced
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center pt-4">
                    <button onClick={() => setIsPanelOpen(true)}>
                      <PanelRightOpen className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Highlight Tooltip State */}
          <TabsContent value="tooltip">
            <div className="max-w-4xl mx-auto">
              <Card>
                <CardContent className="p-8">
                  <div className="mb-8">
                    <div className="bg-blue-900 text-white p-4 rounded-lg mb-6">
                      <h2 className="text-xl font-semibold">Federal Student Aid</h2>
                      <p className="text-sm opacity-90">FAFSA® Application</p>
                    </div>

                    <h3 className="text-lg font-semibold mb-4">Parent Information</h3>
                    <p className="text-sm mb-4">
                      Select the following text to see the highlight tooltip:
                    </p>

                    <div className="relative">
                      <div className="border-2 border-primary/50 bg-primary/5 rounded-lg p-4 cursor-pointer">
                        <label className="block text-sm font-medium mb-2">
                          What is your parent's adjusted gross income (AGI) from their 2025 tax
                          return?
                        </label>
                        <Input placeholder="Enter amount" className="max-w-xs" />
                      </div>

                      {/* Tooltip Popover */}
                      <div className="absolute top-full mt-2 left-0 right-0 z-10">
                        <Card className="border-2 border-primary shadow-xl max-w-md">
                          <CardContent className="p-4 space-y-3">
                            <div>
                              <p className="text-sm font-semibold mb-1">What this means</p>
                              <p className="text-sm text-muted-foreground">
                                AGI is your parent's total income minus specific deductions,
                                found on their tax return.
                              </p>
                            </div>

                            <div>
                              <p className="text-sm font-semibold mb-1">What to enter</p>
                              <p className="text-sm text-muted-foreground">
                                The dollar amount from line 11 of their Form 1040
                              </p>
                            </div>

                            <div>
                              <p className="text-sm font-semibold mb-2">Where to find it</p>
                              <div className="flex items-start gap-2 text-xs text-muted-foreground bg-muted p-2 rounded">
                                <FileText className="w-4 h-4 flex-shrink-0" />
                                <span>Form 1040 (2025) - Line 11, Page 1</span>
                              </div>
                            </div>

                            <div className="pt-3 border-t border-border">
                              <ConfidenceMeter level="high" />
                              <div className="flex gap-2 mt-3">
                                <Input value="$45,230" className="flex-1" readOnly />
                                <Button onClick={handleCopy}>
                                  {copiedValue ? (
                                    <>
                                      <CheckCircle2 className="w-4 h-4 mr-2" />
                                      Copied!
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-4 h-4 mr-2" />
                                      Copy value
                                    </>
                                  )}
                                </Button>
                              </div>
                            </div>

                            <Button variant="link" size="sm" className="w-full p-0 h-auto text-xs">
                              Not right? Give feedback
                            </Button>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </div>

                  <div className="bg-secondary/30 border border-border rounded-lg p-4">
                    <p className="text-sm text-muted-foreground">
                      <strong className="text-foreground">In the actual extension:</strong> This
                      tooltip appears when you highlight any FAFSA question. It provides
                      context-aware help and lets you copy pre-filled values with one click.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <div className="mt-8 text-center">
                <Button onClick={() => navigate("/dashboard")}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Info Banner */}
        <Card className="mt-8 border-primary/30 bg-secondary/20">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-3">How the extension keeps you in control</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex gap-2">
                <span className="text-primary flex-shrink-0">✓</span>
                <span>
                  <strong>No autofill:</strong> We never automatically fill in form fields. You
                  always review and manually enter or paste values.
                </span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary flex-shrink-0">✓</span>
                <span>
                  <strong>Copy, don't submit:</strong> The extension provides a "Copy" button so
                  you can paste values yourself.
                </span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary flex-shrink-0">✓</span>
                <span>
                  <strong>Works only on studentaid.gov:</strong> The extension only activates on
                  the official FAFSA website for your security.
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <MobileNav />
    </div>
  );
}