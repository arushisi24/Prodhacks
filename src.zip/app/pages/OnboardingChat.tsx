import { useState } from "react";
import { useNavigate } from "react-router";
import { ChatBubble } from "../components/ChatBubble";
import { QuickReply } from "../components/QuickReply";
import { ProgressStepper } from "../components/ProgressStepper";
import { MobileNav } from "../components/MobileNav";
import { WelcomeOverlay } from "../components/WelcomeOverlay";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Progress } from "../components/ui/progress";
import { ChevronDown, ChevronUp, Send, Lock } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "../components/ui/collapsible";

export function OnboardingChat() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [progress, setProgress] = useState(15);
  const [inputValue, setInputValue] = useState("");
  const [showWelcome, setShowWelcome] = useState(() => {
    return !localStorage.getItem("fafsa-buddy-welcome-seen");
  });
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: "bot" as const,
      message: "Hi! I'm FAFSA Buddy. I'm here to help you complete your FAFSA application.",
    },
    {
      id: 2,
      sender: "bot" as const,
      message: "You're not behind — FAFSA is confusing. We'll do it together.",
    },
    {
      id: 3,
      sender: "bot" as const,
      message: "First, let's understand your situation. Why are you applying for FAFSA?",
    },
  ]);

  const steps = [
    { number: 1, title: "Goal & basics", status: "current" as const },
    { number: 2, title: "Household/dependency", status: "upcoming" as const },
    { number: 3, title: "Taxes & income", status: "upcoming" as const },
    { number: 4, title: "Assets & banking", status: "upcoming" as const },
    { number: 5, title: "Schools & timing", status: "upcoming" as const },
    { number: 6, title: "Checklist", status: "upcoming" as const },
  ];

  const handleQuickReply = (reply: string) => {
    setMessages([...messages, { id: messages.length + 1, sender: "user", message: reply }]);
    setTimeout(() => {
      if (currentStep === 1) {
        setMessages((prev) => [
          ...prev,
          {
            id: prev.length + 1,
            sender: "bot",
            message: "Great! Are you a first-year student?",
          },
        ]);
        setCurrentStep(2);
        setProgress(25);
      }
    }, 500);
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;
    setMessages([...messages, { id: messages.length + 1, sender: "user", message: inputValue }]);
    setInputValue("");
  };

  const handleComplete = () => {
    navigate("/checklist");
  };

  return (
    <>
      {showWelcome && (
        <WelcomeOverlay
          onClose={() => {
            setShowWelcome(false);
            localStorage.setItem("fafsa-buddy-welcome-seen", "true");
          }}
        />
      )}
      <div className="flex h-screen bg-background pb-16 lg:pb-0">
        {/* Desktop: Left Sidebar with Stepper */}
        <div className="hidden lg:flex w-80 bg-card border-r border-border flex-col">
          <div className="p-6 border-b border-border">
            <h2 className="text-xl font-semibold mb-2">Getting to know you</h2>
            <p className="text-sm text-muted-foreground">
              Answer a few questions so we can personalize your checklist
            </p>
          </div>
          <div className="p-6 flex-1">
            <ProgressStepper steps={steps} />
          </div>
          <div className="p-6 border-t border-border">
            <Button variant="ghost" className="w-full">
              Save & exit
            </Button>
          </div>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="bg-card border-b border-border p-4 md:p-6">
            <div className="max-w-4xl mx-auto flex items-center justify-between">
              <div>
                <h1 className="text-xl md:text-2xl font-semibold">FAFSA Buddy</h1>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <Lock className="w-4 h-4" />
                  <span>Private session</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate("/style-guide")}
                  className="hidden lg:flex"
                >
                  Style Guide
                </Button>
                <div className="hidden md:block">
                  <div className="text-sm text-muted-foreground mb-1">Progress</div>
                  <div className="flex items-center gap-2">
                    <Progress value={progress} className="w-32" />
                    <span className="text-sm font-medium">{progress}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Progress */}
          <div className="md:hidden bg-card border-b border-border px-4 py-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Progress</span>
              <span className="text-sm font-medium">{progress}%</span>
            </div>
            <Progress value={progress} />
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6">
            <div className="max-w-4xl mx-auto space-y-4">
              {messages.map((msg) => (
                <ChatBubble
                  key={msg.id}
                  message={msg.message}
                  sender={msg.sender}
                  expandableContent={
                    msg.sender === "bot" && msg.id === 3 ? (
                      <Collapsible>
                        <CollapsibleTrigger className="flex items-center gap-1 text-sm text-primary hover:underline">
                          <span>Why we ask this</span>
                          <ChevronDown className="w-4 h-4" />
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2 text-sm text-muted-foreground">
                          Understanding your reason helps us determine your eligibility and guide you
                          to the right forms and documentation.
                        </CollapsibleContent>
                      </Collapsible>
                    ) : undefined
                  }
                />
              ))}

              {/* Quick Replies */}
              {currentStep === 1 && (
                <div className="flex flex-wrap gap-2 justify-start">
                  <QuickReply
                    text="Need help paying for college"
                    onClick={() => handleQuickReply("Need help paying for college")}
                  />
                  <QuickReply
                    text="Not sure what I qualify for"
                    onClick={() => handleQuickReply("Not sure what I qualify for")}
                  />
                  <QuickReply
                    text="School told me to apply"
                    onClick={() => handleQuickReply("School told me to apply")}
                  />
                </div>
              )}

              {currentStep === 2 && (
                <div className="flex flex-wrap gap-2 justify-start">
                  <QuickReply text="Yes" onClick={() => handleQuickReply("Yes")} />
                  <QuickReply text="No" onClick={() => handleQuickReply("No")} />
                  <QuickReply text="I don't know" onClick={() => handleQuickReply("I don't know")} />
                </div>
              )}

              {/* Demo: Show complete button after a few steps */}
              {currentStep >= 2 && (
                <div className="pt-8">
                  <div className="bg-secondary/50 border border-primary/20 rounded-lg p-6 text-center">
                    <p className="text-muted-foreground mb-4">
                      Demo: Skip to document checklist
                    </p>
                    <Button onClick={handleComplete} size="lg">
                      Continue to Checklist
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Chat Input */}
          <div className="bg-card border-t border-border p-4 md:p-6">
            <div className="max-w-4xl mx-auto">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSend()}
                  placeholder="Type your answer…"
                  className="flex-1 text-base"
                />
                <Button onClick={handleSend}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex justify-center mt-3">
                <Button variant="ghost" size="sm" onClick={() => handleQuickReply("I don't know")}>
                  I don't know
                </Button>
              </div>
              <p className="text-xs text-muted-foreground text-center mt-3">
                If you're not sure, choose "I don't know" and we'll help you find it.
              </p>
            </div>
          </div>
        </div>

        <MobileNav />
      </div>
    </>
  );
}