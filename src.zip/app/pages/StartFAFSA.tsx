import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { MobileNav } from "../components/MobileNav";
import { ExternalLink, ArrowLeft, Globe, Power, MousePointer } from "lucide-react";

export function StartFAFSA() {
  const navigate = useNavigate();

  const steps = [
    {
      number: 1,
      icon: Globe,
      title: "Open the official FAFSA site",
      description: "We'll open studentaid.gov in a new tab so you can log in or create an account.",
    },
    {
      number: 2,
      icon: Power,
      title: "Turn on FAFSA Buddy extension",
      description:
        "Click the extension icon in your browser toolbar to activate assistance on the FAFSA site.",
    },
    {
      number: 3,
      icon: MousePointer,
      title: "Highlight any question to get help",
      description:
        "Select text on the FAFSA form to see explanations and copy pre-filled values from your documents.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 md:px-6 py-6">
          <Button
            variant="ghost"
            size="sm"
            className="mb-4"
            onClick={() => navigate("/dashboard")}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl md:text-4xl font-semibold mb-3">Let's Start Your FAFSA</h1>
          <p className="text-base text-muted-foreground">
            Follow these simple steps to complete your application with FAFSA Buddy
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 md:px-6 py-8 md:py-12">
        {/* Steps */}
        <div className="space-y-6 mb-12">
          {steps.map((step, index) => (
            <Card key={step.number}>
              <CardContent className="p-6">
                <div className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <step.icon className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-sm font-semibold text-muted-foreground">
                        STEP {step.number}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <Card className="border-2 border-primary bg-gradient-to-br from-primary/5 to-secondary/30">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-semibold mb-3">Ready to begin?</h2>
            <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
              We'll open the FAFSA website in a new tab. Make sure the FAFSA Buddy extension is
              installed and enabled in your browser.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button size="lg" onClick={() => navigate("/extension")}>
                Open FAFSA in new tab
                <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
              <Button size="lg" variant="outline" onClick={() => navigate("/extension")}>
                See extension demo
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Important Note */}
        <div className="mt-8 bg-secondary/30 border border-border rounded-lg p-6">
          <h3 className="font-semibold mb-3">Important to know</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex gap-2">
              <span className="text-primary">•</span>
              <span>
                <strong className="text-foreground">We never autofill or submit for you.</strong>{" "}
                You're always in control of what information you enter.
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary">•</span>
              <span>
                <strong className="text-foreground">You can copy suggested values</strong> with one
                click, but you should always verify they're correct.
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary">•</span>
              <span>
                <strong className="text-foreground">The extension only works on studentaid.gov</strong>{" "}
                to keep your information secure.
              </span>
            </li>
          </ul>
        </div>
      </div>

      <MobileNav />
    </div>
  );
}