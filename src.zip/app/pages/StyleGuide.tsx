import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { ChatBubble } from "../components/ChatBubble";
import { QuickReply } from "../components/QuickReply";
import { ChecklistItem } from "../components/ChecklistItem";
import { DocumentCard } from "../components/DocumentCard";
import { UploadDropzone } from "../components/UploadDropzone";
import { ProgressStepper } from "../components/ProgressStepper";
import { ConfidenceMeter } from "../components/ConfidenceMeter";
import { InfoBanner } from "../components/InfoBanner";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router";

export function StyleGuide() {
  const navigate = useNavigate();

  const steps = [
    { number: 1, title: "Complete", status: "complete" as const },
    { number: 2, title: "Current", status: "current" as const },
    { number: 3, title: "Upcoming", status: "upcoming" as const },
  ];

  const handleResetWelcome = () => {
    localStorage.removeItem("fafsa-buddy-welcome-seen");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-6">
          <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate("/")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-semibold mb-2">Component Style Guide</h1>
              <p className="text-muted-foreground">
                All reusable components for the FAFSA Buddy application
              </p>
            </div>
            <Button variant="outline" onClick={handleResetWelcome}>
              Show Welcome
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8 space-y-12">
        {/* Typography & Colors */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Typography & Colors</h2>
          <Card>
            <CardContent className="p-6 space-y-4">
              <div>
                <h1>Heading 1</h1>
                <h2>Heading 2</h2>
                <h3>Heading 3</h3>
                <h4>Heading 4</h4>
                <p className="text-base">Body text - Regular paragraph text</p>
                <p className="text-sm text-muted-foreground">Small muted text</p>
              </div>
              <div className="flex gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 rounded bg-primary"></div>
                  <span className="text-sm">Primary</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 rounded bg-secondary"></div>
                  <span className="text-sm">Secondary</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 rounded bg-muted"></div>
                  <span className="text-sm">Muted</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 rounded bg-destructive"></div>
                  <span className="text-sm">Destructive</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Buttons */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Buttons</h2>
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="flex gap-3 flex-wrap">
                <Button>Primary Button</Button>
                <Button variant="secondary">Secondary Button</Button>
                <Button variant="outline">Outline Button</Button>
                <Button variant="ghost">Ghost Button</Button>
                <Button variant="destructive">Destructive Button</Button>
              </div>
              <div className="flex gap-3 flex-wrap">
                <Button size="sm">Small</Button>
                <Button size="default">Default</Button>
                <Button size="lg">Large</Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Badges */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Badges</h2>
          <Card>
            <CardContent className="p-6">
              <div className="flex gap-2 flex-wrap">
                <Badge>Default</Badge>
                <Badge variant="secondary">Secondary</Badge>
                <Badge variant="outline">Outline</Badge>
                <Badge variant="destructive">Destructive</Badge>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Chat Components */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Chat Components</h2>
          <Card>
            <CardContent className="p-6 space-y-4">
              <ChatBubble
                sender="bot"
                message="This is a bot message. It helps guide users through the FAFSA process."
              />
              <ChatBubble
                sender="user"
                message="This is a user message response."
              />
              <div className="flex gap-2 flex-wrap">
                <QuickReply text="Quick reply option" onClick={() => {}} />
                <QuickReply text="Another option" onClick={() => {}} />
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Progress Stepper */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Progress Stepper</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Vertical Stepper</CardTitle>
              </CardHeader>
              <CardContent>
                <ProgressStepper steps={steps} orientation="vertical" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Horizontal Stepper</CardTitle>
              </CardHeader>
              <CardContent>
                <ProgressStepper steps={steps} orientation="horizontal" />
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Checklist Item */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Checklist Item</h2>
          <Card>
            <CardContent className="p-6 space-y-3">
              <ChecklistItem
                title="Required Document"
                required={true}
                status="missing"
                whyNeeded="This explains why the document is needed for FAFSA."
                whereToFind="This tells the user where they can find this document."
              />
              <ChecklistItem
                title="Uploaded Document"
                required={true}
                status="uploaded"
                whyNeeded="Document has been uploaded and is awaiting review."
              />
              <ChecklistItem
                title="Reviewed Document"
                required={false}
                status="reviewed"
                whyNeeded="Document has been verified and approved."
              />
            </CardContent>
          </Card>
        </section>

        {/* Document Card */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Document Card</h2>
          <Card>
            <CardContent className="p-6 space-y-3">
              <DocumentCard
                filename="W-2_2025.pdf"
                type="W-2"
                status="needs-review"
                confidence="high"
              />
              <DocumentCard
                filename="Form_1040_2025.pdf"
                type="Form 1040"
                status="extracted"
                confidence="medium"
              />
              <DocumentCard
                filename="Bank_Statement_Jan_2026.pdf"
                type="Bank Statement"
                status="verified"
                confidence="high"
              />
            </CardContent>
          </Card>
        </section>

        {/* Confidence Meter */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Confidence Meter</h2>
          <Card>
            <CardContent className="p-6 space-y-4">
              <ConfidenceMeter level="high" />
              <ConfidenceMeter level="medium" />
              <ConfidenceMeter level="low" />
            </CardContent>
          </Card>
        </section>

        {/* Upload Dropzone */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Upload Dropzone</h2>
          <Card>
            <CardContent className="p-6">
              <UploadDropzone onFileSelect={(files) => console.log(files)} />
            </CardContent>
          </Card>
        </section>

        {/* Info Banners */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">Info Banners</h2>
          <Card>
            <CardContent className="p-6 space-y-4">
              <InfoBanner
                message="You're not behind — FAFSA is confusing. We'll do it together."
                variant="info"
              />
              <InfoBanner
                message="If you're not sure, choose 'I don't know' and we'll help you find it."
                variant="info"
              />
              <InfoBanner
                message="We never submit FAFSA for you. We help you understand and copy the right values."
                variant="warning"
              />
            </CardContent>
          </Card>
        </section>

        {/* Spacing System */}
        <section>
          <h2 className="text-2xl font-semibold mb-6">8pt Spacing System</h2>
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-primary"></div>
                  <span className="text-sm">2px (0.5)</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-4 h-4 bg-primary"></div>
                  <span className="text-sm">4px (1)</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 bg-primary"></div>
                  <span className="text-sm">8px (2) - Base unit</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary"></div>
                  <span className="text-sm">12px (3)</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-primary"></div>
                  <span className="text-sm">16px (4)</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-24 h-24 bg-primary"></div>
                  <span className="text-sm">24px (6)</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}