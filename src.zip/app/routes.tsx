import { createBrowserRouter } from "react-router";
import { OnboardingChat } from "./pages/OnboardingChat";
import { DocumentChecklist } from "./pages/DocumentChecklist";
import { Dashboard } from "./pages/Dashboard";
import { StartFAFSA } from "./pages/StartFAFSA";
import { ExtensionDemo } from "./pages/ExtensionDemo";
import { StyleGuide } from "./pages/StyleGuide";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: OnboardingChat,
  },
  {
    path: "/checklist",
    Component: DocumentChecklist,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
  {
    path: "/start-fafsa",
    Component: StartFAFSA,
  },
  {
    path: "/extension",
    Component: ExtensionDemo,
  },
  {
    path: "/style-guide",
    Component: StyleGuide,
  },
]);